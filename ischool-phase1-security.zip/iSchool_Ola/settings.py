from pathlib import Path
from datetime import timedelta
import os
from decouple import config
from dotenv import load_dotenv
from celery.schedules import crontab
import logging
import dj_database_url
from corsheaders.defaults import default_headers
from corsheaders.defaults import default_methods

# Load .env file
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(os.path.join(BASE_DIR, '.env'))

SECRET_KEY = config('SECRET_KEY')
DEBUG = config('DEBUG', default=False, cast=bool)

# ALLOWED_HOSTS — always prefer the explicit env var, in every environment.
# Falling back to ['*'] only when DEBUG is on AND nothing is configured means a
# single stray DEBUG=True in production can't silently open the host to the world
# unless ALLOWED_HOSTS is also empty.
_hosts = config('ALLOWED_HOSTS', default='')
if _hosts:
    ALLOWED_HOSTS = [h.strip() for h in _hosts.split(',') if h.strip()]
elif DEBUG:
    ALLOWED_HOSTS = ['*']
else:
    ALLOWED_HOSTS = []

# Application definition
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "core",
    "users",
    "school",
    "corsheaders",
    "rest_framework_simplejwt",
    "teacher_dashboard",
    "student_dashboard",
    "parent_dashboard",
    "test_app",
    "payments",
    "teachers",
    "django_filters",
    "rest_framework.authtoken",
    "elibrary",
    'django_celery_beat',
]

MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "iSchool_Ola.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "iSchool_Ola.wsgi.application"

# Database 
DATABASES = {
    'default': dj_database_url.config(
        default=config('DATABASE_URL'),
        conn_max_age=600,
        ssl_require=True
    )
}

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},  # ✅ Changed from StandardPasswordValidator
]

# Internationalization
LANGUAGE_CODE = "en-us"
TIME_ZONE = "Africa/Lagos"
USE_I18N = True
USE_TZ = True

# Static files
STATIC_URL = "/static/"
STATICFILES_DIRS = [os.path.join(BASE_DIR, 'static')]
STATIC_ROOT = os.path.join(BASE_DIR, "staticfiles")
STATICFILES_STORAGE = "whitenoise.storage.CompressedManifestStaticFilesStorage"

# Media files
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# REST framework settings
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework_simplejwt.authentication.JWTAuthentication',
        'rest_framework.authentication.TokenAuthentication',
    ],
    'DEFAULT_FILTER_BACKENDS': ['django_filters.rest_framework.DjangoFilterBackend'],
    'DEFAULT_PERMISSION_CLASSES': ('rest_framework.permissions.IsAuthenticated',),
}

# JWT Settings
SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(days=1),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=7),
    "AUTH_HEADER_TYPES": ("Bearer",),
    "SIGNING_KEY": config("JWT_SIGNING_KEY", default=SECRET_KEY),
    "USER_ID_FIELD": "id",
    "USER_ID_CLAIM": "user_id",
    "TOKEN_OBTAIN_SERIALIZER": "users.serializers.MyTokenObtainPairSerializer",
}

AUTH_USER_MODEL = 'users.CustomUser'

# Email settings
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'mail.ischool.ng'
EMAIL_PORT = 465
EMAIL_HOST_USER = 'noreply@ischool.ng'
EMAIL_HOST_PASSWORD = os.getenv("EMAIL_HOST_PASSWORD")
EMAIL_USE_SSL = True
DEFAULT_FROM_EMAIL = 'noreply@ischool.ng'
CONTACT_EMAIL = "admin@ischool.ng"

# ============================================
# CORS SETTINGS - Production Ready
# ============================================

if DEBUG:
    CORS_ALLOW_ALL_ORIGINS = True
    CORS_ALLOW_CREDENTIALS = True
else:
    CORS_ALLOW_ALL_ORIGINS = False
    CORS_ALLOW_CREDENTIALS = True
    CORS_ALLOWED_ORIGINS = [
        "https://www.ischool.ng",
        "https://api.ischool.ng",
        'http://localhost:8081',
        # Add your mobile app's production URL if applicable
    ]

CORS_ALLOW_METHODS = [
    'DELETE',
    'GET',
    'OPTIONS',
    'PATCH',
    'POST',
    'PUT',
]

CORS_ALLOW_HEADERS = [
    'accept',
    'accept-encoding',
    'authorization',
    'content-type',
    'dnt',
    'origin',
    'user-agent',
    'x-csrftoken',
    'x-requested-with',
    'Access-Control-Allow-Origin',
]

CORS_PREFLIGHT_MAX_AGE = 600

# ============================================
# CSRF SETTINGS - Production Ready
# ============================================

if DEBUG:
    CSRF_TRUSTED_ORIGINS = [
        "http://localhost:8080",
        "http://localhost:8081",
        "http://127.0.0.1:8080",
        "http://localhost:19000",
    ]
else:
    CSRF_TRUSTED_ORIGINS = [
        "https://www.ischool.ng",
        "https://api.ischool.ng",
        'http://localhost:8081',
    ]

CSRF_COOKIE_SECURE = not DEBUG
CSRF_COOKIE_HTTPONLY = False
CSRF_COOKIE_SAMESITE = 'Lax' if DEBUG else 'Strict'

# ============================================
# Logging - Production Ready
# ============================================

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
        },
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': True,
        },
    },
}

# Paystack
PAYSTACK_PUBLIC_KEY = os.getenv('PAYSTACK_LIVE_PUBLIC_KEY')
PAYSTACK_SECRET_KEY = os.getenv('PAYSTACK_LIVE_SECRET_KEY')
PAYSTACK_CALLBACK_URL = "https://api.ischool.ng/ole-student/verify-payment"
OLE_PAYMENT_CALLBACK_URL = os.getenv("OLE_PAYMENT_CALLBACK_URL", "https://www.ischool.ng/ole-subscription/verify")

PAYSTACK_PLAN_IDS = {
    "monthly": "PLN_ky27i039aj6tws7",
    "ola_monthly": "PLN_ggznevdmbw5pjb4",
    "ola_yearly": "PLN_r1rhq04xs8yd3uv"
}
PAYSTACK_PLAN_AMOUNTS = {
    "monthly": 620000,     # ✅ ₦6,200 in kobo
    "ola_monthly": 610000, # ₦6,100 in kobo (OLA specific)
    "ola_yearly": 5200000, # ✅ Changed from 520000 to 5200000 (₦52,000 in kobo)
}
# Slot prices (in kobo)
SLOT_PRICE_MONTHLY = 620000   # ✅ Changed from 610000 to 620000
SLOT_PRICE_YEARLY = 5200000   # ✅ Changed from 520000 to 5200000

# Celery
CELERY_BROKER_URL = config('REDIS_URL', default='redis://127.0.0.1:6379/0')
CELERY_RESULT_BACKEND = config('REDIS_URL', default='redis://127.0.0.1:6379/0')



CELERY_ACCEPT_CONTENT = ['json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_BEAT_SCHEDULE = {
    'run-weekly-summary-every-monday': {
        'task': 'apps.tasks.weekly_summary.generate_weekly_summary',
        'schedule': crontab(hour=0, minute=0, day_of_week=1),
    },
}

# OpenAI
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")


AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
]

PAYMENT_CALLBACK_URL = "https://api.ischool.ng/api/payments/payment-callback/"

# Africa's Talking SMS Configuration
AFRICASTALKING_USERNAME = config('AFRICASTALKING_USERNAME', default='sandbox')
AFRICASTALKING_API_KEY = config('AFRICASTALKING_API_KEY', default='')
AFRICASTALKING_SENDER_ID = config('AFRICASTALKING_SENDER_ID', default='iSchool')